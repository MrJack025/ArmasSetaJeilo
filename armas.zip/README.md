Setajeilo official texture pack.

Thanks to Mombasa team and MienLoL 2.0 for giving permission to use their texture pack!

By MrJack025
